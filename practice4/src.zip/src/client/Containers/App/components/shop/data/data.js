const listData = [
    {
        name:"SAMMI 小西米家欧韩",
        tit:"2018新款韩版收腰宽松风衣外套潮",
        price:135,
        flag:true,
        count:1,
        //img:require("../../static/image/p1.png"),
        id:1,
    },
    {
        name:"比了娃服饰旗舰店",
        tit:"夏季新款防晒服短款外套",
        price:69,
        flag:false,
        count:1,
        //img:require("../../static/image/p2.png"),
        id:2,
    },
    {
        name:"简妮朵",
        tit:"2018新款不规则套装两个件套时髦",
        price:128,
        flag:false,
        count:1,
        //img:require("../../static/image/p1.png"),
        id:3,
    },
    {
        name:"SAMMI 小西米家欧韩",
        tit:"2018新款韩版收腰宽松风衣外套潮",
        price:135,
        flag:false,
        count:1,
        //img:require("../../static/image/p2.png"),
        id:4,
    },  
]
export default listData