import Shop from './shop'

export default Shop;