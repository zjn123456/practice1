import React, { Component } from 'react'

class Info extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            
        }
    }
    render() {
        return (
            <div className='box'>
                消息
            </div>
        )
    }
    
}

export default Info;
