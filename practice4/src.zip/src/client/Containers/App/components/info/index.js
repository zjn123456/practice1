import Info from './info'

export default Info;